var count = 0 ; // used a global variable 2 points


window.onload = function() // Use a built-in method for the window object 2 points
{
    
    $("#cover").fadeOut(500);
   document.getElementById('folio').innerHTML = "<p>This is our collection. </p>"; // Use the innerHTML property 2 points
    var sometext = document.getElementById('text');  // Use a locally scoped variable 2 points
    var somecontent = document.createTextNode("Enjoy the images slideshow");  //Use the createTextNode() method 2 points
    sometext.appendChild(somecontent);  //Use the  appendChild() method 2 points
   
}

$(document).ready(function() {  // Use a built-in method for the document object 2 points
  var images =["http://lorempixel.com/800/400/sports","http://lorempixel.com/800/400/sports","http://lorempixel.com/700/500/sports","http://lorempixel.com/600/600/sports"];   // Use a 3rd party API 10 points
                     //Use an array 2 points
  var image = $(".wrapper");

  image.css("background-image","url("+images[count]+")");

  setInterval(function() {
    image.fadeOut(5000, function() {
      image.css("background-image","url("+images[count++]+")");
      image.fadeIn(5000);
    });

    if(count == images.length)   //Use an If statement 5 points
                                 //Access a built-in property for the string object 2 points
    {
      count = 0;
    }

  },4000);

                  
 });

$(function() {
		var Accordion = function(el, multiple) {  // A custom function using parameters 5 points
				this.el = el || {};               // Use the 'this' keyword effectively 5 points
				this.multiple = multiple || false;  //Use a logical OR operator 5 points

				var links = this.el.find('.article-title');
				links.on('click', {      //Use a Click event 2 points
						el: this.el,
						multiple: this.multiple
				}, this.dropdown)
		}

		Accordion.prototype.dropdown = function(e) {  //A custom function 2 points
				var $el = e.data.el;
				$this = $(this),
				$next = $this.next();

				$next.slideToggle();
				$this.parent().toggleClass('open');

				if (!e.data.multiple) {   //Use a logical NOT operator 5 points
						$el.find('.accordion-content').not($next).slideUp().parent().removeClass('open');
				};
		}
		var accordion = new Accordion($('.accordion-container'), false);
});

//Use comments throughout 5 points