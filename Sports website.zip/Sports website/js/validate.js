$(document).ready(function () {
    
    $("#Contact_form").submit(function (event) {
        var isValid = true;
        
        //Use form validation on 2 inputs 10 points
        
        var phonePattern = "\d{3}[\-]\d{3}[\-]\d{4}"
        var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
        
        var name = $("#name").val();
        var email = $("#email").val().trim();
        var phone = $("#phone").val().trim();

        if (name == "") {

            $("#name").next().text("This field is required");
            isValid = false;

        }

        
        //Use an If … Else If statement 5 points

        if (email == "") {

            $("#email").next().text("This field is required.");
            isValid = false;

        } else if (!emailPattern.test(email)) {

            $("#email").next().text("Must be a valid email address.");
            isValid = false;

        } else {

            $("#email").next().text("");
        }

        $("#email").val(email);

        if(phone == ""){
            
            $("#phone").next().text("This field is required");
            isValid = false
        }

        if (isValid == false) {

            event.preventDefault();

        }
    }); 
}); 



function previousPage() {   //Use the History object 10 points
    window.history.back(); 
} 

window.onload=function(){
       $("#name").focus();  //Use a Focus event 2 points
    $("#cover").fadeOut(750);
    var D = new Date;  // Create a Date object 5 points
    var date = D.getFullYear()+'-'+(D.getMonth()+1)+'-'+D.getDate();  //Use a built-in method for the Date object 2 points
   document.getElementById("date").innerHTML = date;
}
